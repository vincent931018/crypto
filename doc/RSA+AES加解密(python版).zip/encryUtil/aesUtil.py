# -*- coding: UTF-8 -*-
# auth: caowencheng<845982120@qq.com>
# date: 2018/4/12

from Crypto.Cipher import AES
import base64

aesKey = 'abcdefgh12345678'

# padding算法
BS = AES.block_size  # aes数据分组长度为128 bit
pad = lambda s: s + (BS - len(s) % BS) * chr(0)


class AesDemo:
    def __init__(self, key, mode):
        self.key = key
        self.mode = mode

    def encrypt(self, plaintext):
        cipher = AES.new(self.key, self.mode)
        cipher_text = cipher.encrypt(pad(plaintext))
        return base64.encodestring(cipher_text)

    def decrypt(self, cipher_text):
        cipher = AES.new(self.key, self.mode)
        cipher_text = base64.decodestring(cipher_text)
        plaintext = cipher.decrypt(cipher_text)
        return plaintext.rstrip(chr(0))


# 测试模块
if __name__ == '__main__':
    demo = AesDemo(aesKey, AES.MODE_ECB)

    e = demo.encrypt('哈哈')
    d = demo.decrypt('5mLeKAMQuRDlqCeIbMoYyw==')
    print("加密：" + e)
    print("解密：" + d)