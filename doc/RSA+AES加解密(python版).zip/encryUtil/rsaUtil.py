# -*- coding: UTF-8 -*-
# auth: caowencheng<845982120@qq.com>
# date: 2018/4/12

from Crypto import Random
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
from Crypto.PublicKey import RSA
import base64

# 伪随机数生成器
random_generator = Random.new().read
# rsa算法生成实例
rsa = RSA.generate(1024, random_generator)


class RsaDemo:
    def __init__(self):
        pass

    @staticmethod
    def encrypt(plaintext):
        with open('public.pem') as key:
            key = key.read()
            public_key = RSA.importKey(key)
            cipher = Cipher_pkcs1_v1_5.new(public_key)
            cipher_text = base64.b64encode(cipher.encrypt(plaintext))
            return cipher_text

    @staticmethod
    def decrypt(cipher_text):
        with open('private.pem') as key:
            key = key.read()
            private_key = RSA.importKey(key)
            cipher = Cipher_pkcs1_v1_5.new(private_key)
            text = cipher.decrypt(base64.b64decode(cipher_text), random_generator)
            return text


# 测试模块
if __name__ == '__main__':
    demo = RsaDemo()
    e = demo.encrypt('哈哈')
    d = demo.decrypt(e)
    print("加密：" + e)
    print("解密：" + d)
