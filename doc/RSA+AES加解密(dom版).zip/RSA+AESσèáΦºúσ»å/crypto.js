const RSA = function() {
    // 获取公钥KEY
    var publicKey = 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAMCrdgjeIZWPJ/KY0MDOf5T7paPsodjBuUW7eDdfdv+p5+caG5uP7LIwyyLg+dYXokrAJFaBw6KYC808hjiIWZsCAwEAAQ==';
    // 获取私钥KEY
    var privateKey = 'MIIBOgIBAAJBAMCrdgjeIZWPJ/KY0MDOf5T7paPsodjBuUW7eDdfdv+p5+caG5uP7LIwyyLg+dYXokrAJFaBw6KYC808hjiIWZsCAwEAAQJAbnZfd/oS+zJWTup6VPCPiRU2BGO47xMya95tsCGVkkIRaFNaqOmUGjtCZZK78fov+lcXzistKRoMd2/vw50PcQIhAPYUSQqz6CrJPGkPWQBQR4UX2Oxx/B5kAjD/TaaRf6BXAiEAyG/znbEGd8wLLQXbKtv1Wv29OHvPTQ1fPiwFXNr1dl0CIQCvo5Dy07A9gb7dmffDkolJxNivAziZlHY/9Km+3xECJwIgBOZHrDkhkVgZhdY4z0llK/4729+a56VGCL0GvIhVq7kCIDvVtKVaibSN89KgHewCd/PbyFICKSTDbdwLSFXcLOjN';
    // 获取AES秘钥
    var password = 'ZFR6X2OQQK669S4F';
    // REA加密组件JS方法
    var RSAUtils = new JSEncryptExports.JSEncrypt();
    // 设置公钥
    RSAUtils.setPublicKey(publicKey);
    // 设置私钥
    RSAUtils.setPublicKey(privateKey);
    return {
        // AES随机秘钥生成算法16位字符拼接
        generateMixed: function() {
            var jschars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
            var key = "";
            for (var i = 0; i < 16; i++) {
                var id = Math.ceil(Math.random() * 35);
                key += jschars[id];
            }
            return key;
        },
        AES_Encode: function(plain_text) {
            GibberishAES.size(128);
            return GibberishAES.aesEncrypt(plain_text, password);
        },
        AES_Decode: function(plain_text) {
            return GibberishAES.aesDecrypt(plain_text, password);
        },
        RSA_Encode: function(key) {
            return RSAUtils.encrypt(key);
        },
        RSA_Decode: function(key) {
            return RSAUtils.decrypt(key);
        }
    };
};

const rsa = new RSA();

// 随机生成AES加密密钥
const AESPassword = rsa.generateMixed();

const RSAEncrypt = function(text) {
    if(!text) {
        throw new Error('请输入明文');
    }
    return rsa.RSA_Encode(text);
};

const RSADecrypt = function(text) {
    if(!text) {
        throw new Error('请输入密文');
    }
    return rsa.RSA_Decode(text);
};

const AESEncrypt = function(text) {
    if(!text) {
        throw new Error('请输入明文');
    }
    return rsa.AES_Encode(text);
};

const AESDecrypt = function(text) {
    if(!text) {
        throw new Error('请输入密文');
    }
    return rsa.AES_Decode(text);
};

const str = "哈哈";

let AESencryptStr = AESEncrypt(str);
let AESdecryptStr = AESDecrypt(AESencryptStr);
let RSAEncryptStr = RSAEncrypt(str);
let RSADecryptStr = RSADecrypt(RSAEncryptStr);
console.log("AES加密后：" + AESencryptStr);
console.log("AES解密后：" + AESdecryptStr);
console.log("RSA加密后：" + RSAEncryptStr);
console.log("RSA解密后：" + RSADecryptStr);

