const RSA = function() {
    // 获取公钥KEY
    var publicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC16IykYd1LJuaGBbFB8q6HfGNyf0/pq39kcRyR1hGA/1R6TWQpfRx3PkEBTld6h2dxZgoj/SxnYIQLaK0DEanWncu+H+3/dqO4OTfESwDYWYKH8DZZE3Dz9w+qUdUZSe786m8k3qglw/caytW4DbG064j3J7XrhM2/Q8+/HWPuwQIDAQAB';
    // 获取私钥KEY
    var privateKey = 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALXojKRh3Usm5oYFsUHyrod8Y3J/T+mrf2RxHJHWEYD/VHpNZCl9HHc+QQFOV3qHZ3FmCiP9LGdghAtorQMRqdady74f7f92o7g5N8RLANhZgofwNlkTcPP3D6pR1RlJ7vzqbyTeqCXD9xrK1bgNsbTriPcnteuEzb9Dz78dY+7BAgMBAAECgYB8cDjFuqzHXDUWOY6ornr19AGTscPY9ZiP/VCt8uLGe+QuRgLe3tc6Ozv8yLrO9xGsYUFOnUJi9YNeypyQHOUw4+cocBQnQVx7byKPH7wAcHJ++LkTj21f1iKjqfHDLllttvo4zBYpu9rMzkGiGiQXR/M8VTl9k7HZSLY7/0tWgQJBAOKknVwQnbdWlSLn49HieJFxhD3BgKZ0JJTmvBuV+V8r5yUC44frLgxsWDjrhltuO7Im+5aCtFOcX2M9WLXr6PMCQQDNeI24X1mVnkk172g51OrD8DfkkaVlfYuSYrUhHFToOSYfdjcR8pCOZxQycvaEXSN05D4IB81RcoioBU7kaXZ7AkEAvlIx+m/RoXXJwwgr3cJqMOi8fgeSezUoywl/iULFqE/7yK7GVwr9Hl2VMCdIKltFMfNebiPQPi4gQ/vuFMbIVQJAA2rX4JMlaEmjqhP7Rcr2xJ+ALnsFpzR5V8vwe0Z/WwVoTummbNP994BbY6Np2jW6Wz1YksWecpZXE4RTFZVzdQJAEJacH7f9lI05T5OXs3XhMBOiS2Gi6hswnFChSpMRmMLVtiyfYDoRFZ6s2IV2WyqiF9rLvW0BT6RYNOeHPAbjGQ==';
    // 获取AES秘钥
    var password = CryptoJS.enc.Utf8.parse("abcdefgh12345678");
    // REA加密组件JS方法
    var RSAUtils = new JSEncryptExports.JSEncrypt();
    // 设置公钥
    RSAUtils.setPublicKey(publicKey);
    // 设置私钥
    RSAUtils.setPublicKey(privateKey);
    return {
        // AES随机秘钥生成算法16位字符拼接
        generateMixed: function() {
            var jschars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
            var key = "";
            for (var i = 0; i < 16; i++) {
                var id = Math.ceil(Math.random() * 35);
                key += jschars[id];
            }
            return key;
        },
        AES_Encode: function(plain_text) {
            var encryptedData = CryptoJS.AES.encrypt(plain_text, password, {
                mode: CryptoJS.mode.ECB,  
                padding: CryptoJS.pad.Pkcs7 
            });
            return encryptedData.toString();
        },
        AES_Decode: function(plain_text) {
            var decryptedData = CryptoJS.AES.decrypt(plain_text, password, {  
                mode: CryptoJS.mode.ECB,  
                padding: CryptoJS.pad.Pkcs7  
            }); 
            var decryptedStr = decryptedData.toString(CryptoJS.enc.Utf8);
            return decryptedStr;
        },
        RSA_Encode: function(key) {
            return RSAUtils.encrypt(key);
        },
        RSA_Decode: function(key) {
            return RSAUtils.decrypt(key);
        }
    };
};

const rsa = new RSA();

// 随机生成AES加密密钥
const AESPassword = rsa.generateMixed();

const RSAEncrypt = function(text) {
    if(!text) {
        throw new Error('请输入明文');
    }
    return rsa.RSA_Encode(text);
};

const RSADecrypt = function(text) {
    if(!text) {
        throw new Error('请输入密文');
    }
    return rsa.RSA_Decode(text);
};

const AESEncrypt = function(text) {
    if(!text) {
        throw new Error('请输入明文');
    }
    return rsa.AES_Encode(text);
};

const AESDecrypt = function(text) {
    if(!text) {
        throw new Error('请输入密文');
    }
    return rsa.AES_Decode(text);
};

// 点击加密按钮
function encrypt() {
    var plain = document.getElementById("painttext");
    var crypto = document.getElementById("cryptotext");
    var plainValue = plain.value;
    var cryptoValue = crypto.value;
    if(!plainValue){
        alert('请需加密入参json');
        return;
    }
    try{
        var originJson = JSON.parse(plainValue);
    } catch(e){
        console.log(e.message);
        alert('请输入正确json');
        return;
    }
    try{
        var returnJson = {};
        // RSA加密
        returnJson.content = AESEncrypt(plainValue);
        returnJson.key = RSAEncrypt('abcdefgh12345678');
        crypto.value = JSON.stringify(returnJson);
    } catch(e) {
        console.log(e.message);
        alert('加解密失败');
        return;
    }
}

// 点击解密按钮
function decrypt() {
    var crypto = document.getElementById("painttext");
    var plain = document.getElementById("cryptotext");
    var cryptoValue = crypto.value;
    var plainValue = plain.value;
    var originJson;
    if(!cryptoValue){
        alert('请需解密出参json');
        return;
    }
    try{
        originJson = JSON.parse(cryptoValue);
    } catch(e){
        console.log(e.message);
        alert('请输入正确json');
        return;
    }
    try{
        var returnJson = {};
        // RSA加密
        returnJson = AESDecrypt(originJson.content);
        plain.value = JSON.stringify(returnJson);
    } catch(e) {
        console.log(e.message);
        alert('加解密失败');
        return;
    }
}
