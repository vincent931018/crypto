package cn.lanrenyun.msgatewaylryj.utils;

import javax.crypto.Cipher;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

/**
 * RSA密钥生成、加解密
 */
public class RSA {

    /** RSA:加密算法 */
    public static final String  KEY_ALGORITHM =             "RSA";

    public static final String  KEY_ALGORITHM_RSA_NONE =             "RSA/ECB/PKCS1Padding";

    /** SHA1WithRSA:用SHA算法进行签名，用RSA算法进行加密 */
    public static final String  SIGN_ALGORITHMS =           "SHAWithRSA";

    /** 公钥KEY*/
    public static final String  PUB_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCx2zk90WzGIzGjl7opxIFdoinxyp+pjvN1wC0OTrGk6o/c0RyrmQstu690IJPXu/6urLmB7/T2Iy/UUvSkqwzL7oX6D7llTjyR4MQjwvPVy7JZR2WYu1dvPgQn++/DVBuFDtfYW6pRlIi27iPxXyQ3ozAfHo5biR5nNelhu0lnVQIDAQAB";

    /* 私钥 */
    public static final String  PRI_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALHbOT3RbMYjMaOXuinEgV2iKfHKn6mO83XALQ5OsaTqj9zRHKuZCy27r3Qgk9e7/q6suYHv9PYjL9RS9KSrDMvuhfoPuWVOPJHgxCPC89XLsllHZZi7V28+BCf778NUG4UO19hbqlGUiLbuI/FfJDejMB8ejluJHmc16WG7SWdVAgMBAAECgYEAmfYICzdrTenRYqhJgzaUNhXW8XRR2lng7yG43xXIOdbDSofKpdEKGEDMlV5OHQakZVkoDQ9Honq7QLW/CXz4yW71iAK8SFn22LGKxzdSgPZkGmVZ+ZKDPjmKg9QyzI8VbHWKuIHCD0iJgaN7SF5B1CtsGRs66f+aNTLyLLr2QAECQQDWtXfjJi0keQ13mLpAYfc7e7dX0zna5zqkUbA2q1JYPG8j9GIJ/j3NrUUJbhFiBEJUX5BYtP7zXOXA8/QNqvtVAkEA1A9vRllNQNEiAG3ZlvVSh3RXWPsVDQkerzWKBlMvQZIa+eQ/Q9o+b0tOvvt1IIvwaSXpqBEcpC09vzfjoNy8AQJBAMNUmFr4Uj1KO6xAL8F+3pMo/CVULuAtWLZA8tTpi6JmaJ4HKGH7AHLrXVE052+KfGWSAxoQn5j7PLILvk3o7XkCQDcG4ksQ9Tjyi64s0x+W/RllGR1f2fCOA0ZX0D8f6s1LCnD5x2jmAvmCQybPvW76oSHH0r/n4NTBYJpz+D9PyAECQG+WZ/QoXpyHiRr1JUdjq2BX7+EA8hsC6+pmBzOnRzbOxWxmlfMNC5gzhhOyAVMdQM8UaRgKBOSsqsWz6artj1Y=";

    /** 块加密的大小，是不要太大，否则效率会低 */
    private static final int    KEY_SIZE =                  1024;

    /** 获取公钥的key */
    public static final String PUBLIC_KEY =                "RSAPublicKey";

    /** 获取私钥的key */
    public static final String PRIVATE_KEY =               "RSAPrivateKey";

    /** RSA最大加密明文大小 */
    private static final int    MAX_ENCRYPT_BLOCK =        117;

    /** RSA最大解密密文大小 */
    private static final int    MAX_DECRYPT_BLOCK =         128;


    /**
     * * 生成密钥对 *
     *
     * @return KeyPair *
     * @throws Exception
     */
    public static KeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);
        keyPairGen.initialize(KEY_SIZE, new SecureRandom());
        KeyPair keyPair = keyPairGen.generateKeyPair();
        return keyPair;
    }

    /**
     * * 生成公钥 *
     *
     * @param keyPair *
     * @return RSAPublicKey *
     * @throws Exception
     */
    public static String generateRSAPublicKey(KeyPair keyPair) throws Exception {

        RSAPublicKey publicKey = (RSAPublicKey)keyPair.getPublic();
        return Base64.encode(publicKey.getEncoded());
    }

    /**
     * * 生成私钥 *
     *
     * @param keyPair *
     * @return RSAPublicKey *
     * @throws Exception
     */
    public static String generateRSAPrivateKey(KeyPair keyPair) throws Exception {

        RSAPrivateKey privateKey = (RSAPrivateKey)keyPair.getPrivate();
        return Base64.encode(privateKey.getEncoded());
    }

    /**
     * * 生成公私钥对 *
     *
     * @return Map *
     * @throws Exception
     */
    public static Map<String, Object> generateRSAKey() throws Exception {
        KeyPair keyPair = generateKeyPair();
        Map<String, Object> keyMap = new HashMap<String, Object>(2);
        keyMap.put(PUBLIC_KEY, generateRSAPublicKey(keyPair));
        keyMap.put(PRIVATE_KEY, generateRSAPrivateKey(keyPair));
        return keyMap;
    }

    /**
     * 用私钥对信息生成数字签名
     *
     * @param content                待签名数据
     * @param privateKey             私钥(BASE64编码)
     * @param input_charset          编码格式
     * @return                       签名值
     */
    public static String sign(String content, String privateKey, String input_charset) throws Exception {
        PKCS8EncodedKeySpec priPKCS8 	= new PKCS8EncodedKeySpec( Base64.decode(privateKey) );
        KeyFactory keyf 				= KeyFactory.getInstance(KEY_ALGORITHM);
        PrivateKey priKey 				= keyf.generatePrivate(priPKCS8);

        Signature signature = Signature.getInstance(SIGN_ALGORITHMS);
        signature.initSign(priKey);
        signature.update(content.getBytes(input_charset));
        byte[] signed = signature.sign();
        return Base64.encode(signed);
    }

    /**
     * 用公钥对信息RSA验签名检查
     *
     * @param content                待签名数据
     * @param sign                   签名值
     * @param yzf_public_key         公钥
     * @param input_charset          编码格式
     * @return                       布尔值
     */
    public static boolean verify(String content, String sign, String yzf_public_key, String input_charset) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        byte[] encodedKey = Base64.decode(yzf_public_key);
        PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));

        Signature signature = Signature.getInstance(SIGN_ALGORITHMS);

        signature.initVerify(pubKey);
        signature.update( content.getBytes(input_charset) );

        return signature.verify(Base64.decode(sign));
    }

    /**
     * 使用公钥RSA加密
     * @param content               明文
     * @param yzf_public_key        公钥
     * @param input_charset         编码格式
     * @return                      解密后的字符串
     */
    public static String encrypt(String content, String yzf_public_key, String input_charset) throws Exception {

        String str = null;
        ByteArrayOutputStream writer = null;
        try {
            PublicKey pubKey = getPublicKey(yzf_public_key);

            Cipher cipher = Cipher.getInstance(KEY_ALGORITHM_RSA_NONE);
            cipher.init(Cipher.ENCRYPT_MODE, pubKey);

            // 设置编码格式
            InputStream ins = new ByteArrayInputStream(content.getBytes(input_charset));
            writer = new ByteArrayOutputStream();

            byte[] buf = new byte[MAX_DECRYPT_BLOCK];
            int bufl;

            while ((bufl = ins.read(buf)) != -1) {
                byte[] block = null;

                if (buf.length == bufl) {
                    block = buf;
                } else {
                    block = new byte[bufl];
                    for (int i = 0; i < bufl; i++) {
                        block[i] = buf[i];
                    }
                }
                writer.write(cipher.doFinal(block));
            }
            str = new String(Base64.encode(writer.toByteArray()));
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writer = null;
            }
        }
        return str;
    }

    /**
     * 使用公钥RSA加密
     * @param content               明文
     * @param yzf_private_key        公钥
     * @param input_charset         编码格式
     * @return                      解密后的字符串
     */
    public static String encryptAndPriKey(String content, String yzf_private_key, String input_charset) throws Exception {

        String str = null;
        ByteArrayOutputStream writer = null;
        try {
            PrivateKey priKey = getPrivateKey(yzf_private_key);

            Cipher cipher = Cipher.getInstance(KEY_ALGORITHM_RSA_NONE);
            cipher.init(Cipher.ENCRYPT_MODE, priKey);

            // 设置编码格式
            InputStream ins = new ByteArrayInputStream(content.getBytes(input_charset));
            writer = new ByteArrayOutputStream();

            byte[] buf = new byte[MAX_DECRYPT_BLOCK];
            int bufl;

            while ((bufl = ins.read(buf)) != -1) {
                byte[] block = null;

                if (buf.length == bufl) {
                    block = buf;
                } else {
                    block = new byte[bufl];
                    for (int i = 0; i < bufl; i++) {
                        block[i] = buf[i];
                    }
                }
                writer.write(cipher.doFinal(block));
            }
            str = new String(Base64.encode(writer.toByteArray()));
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writer = null;
            }
        }
        return str;
    }

    /**
     * 使用私钥RSA解密
     * @param content 密文
     * @param private_key 商户私钥
     * @param input_charset 编码格式
     * @return 解密后的字符串
     */
    public static String decrypt(String content, String private_key, String input_charset) throws Exception {
        PrivateKey prikey = getPrivateKey(private_key);

        Cipher cipher = Cipher.getInstance(KEY_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, prikey);

        InputStream ins = new ByteArrayInputStream(Base64.decode(content));
        ByteArrayOutputStream writer = new ByteArrayOutputStream();
        //rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
        byte[] buf = new byte[MAX_DECRYPT_BLOCK];
        int bufl;

        while ((bufl = ins.read(buf)) != -1) {
            byte[] block = null;

            if (buf.length == bufl) {
                block = buf;
            } else {
                block = new byte[bufl];
                for (int i = 0; i < bufl; i++) {
                    block[i] = buf[i];
                }
            }
            writer.write(cipher.doFinal(block));
        }

        return new String(writer.toByteArray(), input_charset);
    }

    /**
     * 使用私钥RSA解密
     * @param content 密文
     * @param public_key 商户私钥
     * @param input_charset 编码格式
     * @return 解密后的字符串
     */
    public static String decryptAndPucKey(String content, String public_key, String input_charset) throws Exception {
        PublicKey pucKey = getPublicKey(public_key);

        Cipher cipher = Cipher.getInstance(KEY_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, pucKey);

        InputStream ins = new ByteArrayInputStream(Base64.decode(content));
        ByteArrayOutputStream writer = new ByteArrayOutputStream();
        //rsa解密的字节大小最多是128，将需要解密的内容，按128位拆开解密
        byte[] buf = new byte[MAX_DECRYPT_BLOCK];
        int bufl;

        while ((bufl = ins.read(buf)) != -1) {
            byte[] block = null;

            if (buf.length == bufl) {
                block = buf;
            } else {
                block = new byte[bufl];
                for (int i = 0; i < bufl; i++) {
                    block[i] = buf[i];
                }
            }
            writer.write(cipher.doFinal(block));
        }

        return new String(writer.toByteArray(), input_charset);
    }

    /**
     * 得到私钥
     *
     * @param key 密钥字符串（经过base64编码）
     * @throws Exception
     */
    public static PrivateKey getPrivateKey(String key) throws Exception {

        byte[] keyBytes = Base64.decode(key);

        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

        return privateKey;
    }

    /**
     * 得到公钥
     *
     * @param key 加密字符串（经过base64编码）
     * @throws Exception
     */
    public static PublicKey getPublicKey(String key) throws Exception {

        byte[] keyBytes;

        keyBytes = Base64.decode(key);

        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);

        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

        PublicKey publicKey = keyFactory.generatePublic(keySpec);

        return publicKey;
    }

    public static void main(String args[]) {
        try {
            // 公钥
            String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCz892Kczc9RAZlrVNDpcQXvADJ\n" +
                    "kOVdDpg5GekSR0Kdy94eBurkKVPhvaKLFY5brQpIQGmDdfVf7smOegnGiMIud4ib\n" +
                    "kqkKrW9TzhfoyduQI69zgOVWIyR07C/uXt/HB5ltWF3MpwWyzLCbc1ZM/TyBXcI/\n" +
                    "w6W15jgbaXOsvD3pPQIDAQAB";
            // 私钥
            String privKey="MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALPz3YpzNz1EBmWt\n" +
                    "U0OlxBe8AMmQ5V0OmDkZ6RJHQp3L3h4G6uQpU+G9oosVjlutCkhAaYN19V/uyY56\n" +
                    "CcaIwi53iJuSqQqtb1POF+jJ25Ajr3OA5VYjJHTsL+5e38cHmW1YXcynBbLMsJtz\n" +
                    "Vkz9PIFdwj/DpbXmOBtpc6y8Pek9AgMBAAECgYEAmTPuEbgDeFpYo+nLMJWI+7fo\n" +
                    "Z7K/QtlxCXQgtJoMgfEV2jSDd9ojetWK86RXfX81eMu1yOD9FT5jRLRrbCX0QlJ6\n" +
                    "FrJtSRnpFFVhFa5P/oF0D4u98f04pXuvK+KNRxgr8U0QqJF5HoP+rhmy2y4sFJnW\n" +
                    "wYbMjJNtF/DpW8HISNUCQQDo/OJbtnBQP1JCJJEs4yOOoOeqJVVsy2kD8bdcbVSh\n" +
                    "Yg8CzAkh0WVN9D6REv934inE5J9SySd8Elm3GIvF45srAkEAxbn7LohvAkxt0UgD\n" +
                    "WBDhVjWVNqj2QnJE83oBiib44fcST9pHGdBSHWjTF9b9OOXqwXE987srsJ6arIAB\n" +
                    "fuE5NwJBAJ1koMIWKB9992Lpcw1g0Fd9CaNenyvk6ieY9ibBUQfIx507Gvw2ifo0\n" +
                    "gsPckqp5JYB2dc8mRr9BYkwXj+z6SosCQEcYmZ3gxvGvo6kl2LX4092YxL9zv6Ci\n" +
                    "z/IwQ492dfViTr5RwVEh2/ThNU4UKtcjrObDnkAeZBZM4Vb3bBJAT78CQHyAz3z2\n" +
                    "XwnvifaYzIwK6vcALeWPGidHDcCbFprZ/hY3dNqDN0udO+2oioYhO7I75yFUkneL\n" +
                    "Ezbe44eXAUze9ag=";


            String content = "我叫小王";

            String encryStr = RSA.encrypt(content, pubKey, "UTF-8");

            System.out.println("加密结果：" + encryStr);

            String decryptStr = RSA.decrypt(encryStr, privKey, "UTF-8");

            System.out.println("解密结果：" + decryptStr);

        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
